#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    Created on Fri Nov 30 11:18:07 2018
    by a monification of mnist_test.py
    @author: pironneau 
Each data file has img_rows lines of img_cols floats separated by one space
Files are in folders named by one digit
"""
import os
import keras
import tensorflow as tf
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K
print(tf.__version__)

batch_size = 32
epochs = 20
verbatim = 1
# input image dimensions
img_rows, img_cols = 28, 28

def readFFEMdata():  
    #os.chdir(r"./ffdata")
    #os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
    
    print("Looking for data in " + os.getcwd()+"/ffdata/")
       
    name = r"./ffdata/training-images"
    FileList = []
    nb_class = 0
    nb_train=0
    
    for dirname in os.listdir(name):
        path = os.path.join(name,dirname)
        filecount = 0
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                filecount+=1
        nb_class+=1
        nb_train+=filecount
        print(path,filecount)
    
    x_train = np.array(nb_train*[np.array(img_rows*img_cols *[np.float32(0.)])])
    y_train = np.array(nb_train*[np.int(0)])
    nb_train=0
    for dirname in os.listdir(name):
        path = os.path.join(name,dirname)
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                FileList.append(os.path.join(name,dirname,filename))
                # read each file, find min and max
                with open(os.path.join(name,dirname,filename), "r") as file1:
                    y_train[nb_train] = ord(dirname)-ord('0')
                    j=0
                    xmax=-1.0e20
                    xmin=1.0e20
                    for line in file1.readlines():
                        for x in line.split(" ") : 
                            if x.strip():
                                y=float(x)  
                                if y > xmax :
                                    xmax=y
                                if y<xmin:
                                    xmin=y
                                x_train[nb_train][j]=y
                                j+=1
                    # rescale numbers to be in (0,1)
                    for j in range(0,img_rows*img_cols):
                     if xmax!=xmin :
                      x_train[nb_train][j]= (x_train[nb_train][j]-xmin)/(xmax-xmin)
                     else:
                      x_train[nb_train][j]= 0;
                    nb_train+=1

    name = r"./ffdata/test-images"
    FileList = []
    nb_test=0
    
    for dirname in os.listdir(name):
        path = os.path.join(name,dirname)
        filecount = 0
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                if verbatim>1:
                    print(nb_test+filecount,filename )
                filecount+=1
        nb_test +=filecount
        print(path,filecount)
    
    
    x_test = np.array(nb_test*[np.array(img_rows*img_cols *[np.float32(0.)])])
    y_test = np.array(nb_test*[np.int(0)])
    nb_test=0
    for dirname in os.listdir(name):
        path = os.path.join(name,dirname)
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                FileList.append(os.path.join(name,dirname,filename))
                with open(os.path.join(name,dirname,filename), "r") as file1:
                    y_test[nb_test] = ord(dirname)-ord('0')
                    j=0
                    xmax=-1.0e20
                    xmin=1.0e20
                    for line in file1.readlines():
                        for x in line.split(" ") : 
                            if x.strip():
                                y=float(x)
                                if y > xmax :
                                    xmax=y
                                if y<xmin:
                                    xmin=y
                                x_test[nb_test][j]=y
                                j+=1
                    for j in range(0,img_rows*img_cols):
                       if xmax!=xmin :
                           x_test[nb_test][j]= (x_test[nb_test][j]-xmin)/(xmax-xmin)
                       else:
                           x_test[nb_test][j]=0
                    nb_test+=1
     
    print(nb_train,' training files. ',nb_test,
          ' test files. nb_class= ', nb_class)
    print ('End of files reading phase')
    
    return x_train, x_test, y_train, y_test, nb_class, nb_test

######################################################### End read data ######

# the data, split between train and test sets
x_train, x_test, y_train, y_test, num_class, num_test = readFFEMdata()

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

#x_train = x_train.astype('float32')
#x_test = x_test.astype('float32')
#x_train /= 255
#x_test /= 255
print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_class)
y_test = keras.utils.to_categorical(y_test, num_class)
model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3),
                 activation='relu',
                 input_shape=input_shape))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(num_class, activation='softmax'))

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adadelta(),
              metrics=['accuracy'])

model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=1,
          validation_data=(x_test, y_test))
score = model.evaluate(x_test, y_test, verbose=1)

correct = model.predict(x_test).reshape((-1,))
k=0
for i in range(0,num_test):
    kj=0
    ij=0
    for j in range(0, num_class):
        if y_test[i,j] > y_test[i,ij] :
            ij=j           
        if correct[k+j] > correct[k+kj] :
            kj=j
    if (kj==ij)and(verbatim>1) :
        print(i, " GOOD: highest proba= ",correct[k+kj], " at class ", kj)
    if (kj!=ij)and(verbatim>0) :
            print(i, " BAD highest proba= ",correct[k+kj], " at class ", kj, 
                  "   Truth is ", ij, "but proba= ", correct[k+ij] )
    k+=num_class
    
print('Test loss:', score[0])
print('Test accuracy:', score[1])


